https://www.komoot.com/tour/3149958102


A Misurina tó
1 Dellach
2 Villach
3 Dullach
4 Lavamünd
B Maribor